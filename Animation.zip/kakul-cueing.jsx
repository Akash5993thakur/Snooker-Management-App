/* global React, useComposition, CompositionStage, Easing, animate, clamp, useTweaks, TweaksPanel, TweakSection, TweakToggle, TweakColor, TweakText */

const MOTION = {
  ease: Easing.easeOutQuart,   // things arriving, the ball receding under friction
  snap: Easing.easeInQuart,    // the strike itself
  glide: Easing.easeOutSine,   // the ball running out under friction
};

const W = 390, H = 844;
const GUTTER = 40;
const BALL_X = 195, BALL_Y = 430, BALL_R = 26;
const CUE_TIP_Y = BALL_Y + BALL_R + 16;   // tip rests just short of the ball
const FEATHER_CYCLE = 0.45;

// wordmark lockup — identical geometry to the type-led option so the two are interchangeable
const MARK_BOTTOM = 430, MARK_SIZE = 64, MASK_H = 74, BASE_IN_MASK = 58, RULE_Y = 462, DOT = 13;

function Cue({ y, opacity }) {
  // Seen from behind, so the butt is nearer and wider than the tip: a tapered
  // stack, drawn with clip-path here / react-native-svg on device.
  const L = H - CUE_TIP_Y + 120;
  return (
    <div style={{
      position: 'absolute', left: BALL_X - 11, top: CUE_TIP_Y, width: 22, height: L,
      opacity, transform: 'translateY(' + y + 'px) rotate(1.5deg)', transformOrigin: '50% 100%',
    }}>
      <div style={{ position: 'absolute', left: 0, top: 26, width: 22, height: L - 26,
        background: 'linear-gradient(180deg, #C08F4E 0%, #D9AE72 38%, #8A6134 100%)',
        clipPath: 'polygon(41% 0%, 59% 0%, 100% 100%, 0% 100%)' }} />
      <div style={{ position: 'absolute', left: 0, top: L - 190, width: 22, height: 190,
        background: 'linear-gradient(180deg, rgba(31,18,11,0) 0%, #241610 45%, #150C08 100%)',
        clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' }} />
      <div style={{ position: 'absolute', left: 8.4, top: 9, width: 5.6, height: 22, background: '#EFEADC' }} />
      <div style={{ position: 'absolute', left: 8, top: 0, width: 6.4, height: 10, background: '#2E6FD0', borderRadius: '3px 3px 1px 1px' }} />
    </div>
  );
}

function Piece({ tw }) {
  const { T, CUES } = useComposition();
  const accent = tw.accent;

  /* ---- table ---- */
  const feltIn = animate({ from: 0, to: 1, start: 0.05, end: 0.75, ease: MOTION.ease })(T);

  /* ---- ball ---- */
  const ballIn = animate({ from: 0, to: 1, start: 0.18, end: 0.62, ease: MOTION.ease })(T);
  const travelY = animate({ from: 0, to: -(BALL_Y + 90), start: CUES.Travel, end: CUES.Travel + 0.6, ease: MOTION.glide })(T);
  const recede = animate({ from: 1, to: 0.3, start: CUES.Travel, end: CUES.Travel + 0.6, ease: MOTION.glide })(T);
  // contact squash — zero until the tip actually arrives, then recovers over 130ms
  const squash = T < CUES.Travel ? 0
    : animate({ from: 1, to: 0, start: CUES.Travel, end: CUES.Travel + 0.13, ease: MOTION.ease })(T);
  const sx = recede * (1 + 0.22 * squash), sy = recede * (1 - 0.18 * squash);

  /* ---- cue ---- */
  const cueIn = animate({ from: 190, to: 0, start: 0.2, end: CUES.Feather, ease: MOTION.ease })(T);
  const featherPhase = clamp((T - CUES.Feather) / FEATHER_CYCLE, 0, 2);
  const feather = (T >= CUES.Feather && T < CUES.Strike)
    ? -13 * Math.sin(featherPhase * Math.PI * 2) : 0;
  const draw = animate({ from: 0, to: 40, start: CUES.Strike, end: CUES.Strike + 0.28, ease: MOTION.ease })(T);
  const hit = animate({ from: 0, to: 54, start: CUES.Strike + 0.28, end: CUES.Travel, ease: MOTION.snap })(T);
  const followBack = animate({ from: 0, to: 150, start: CUES.Travel + 0.18, end: CUES.Resolve, ease: MOTION.ease })(T);
  const cueY = cueIn + feather + draw - hit + followBack;
  const cueFade = 1 - animate({ from: 0, to: 1, start: CUES.Resolve - 0.15, end: CUES.Resolve + 0.2, ease: MOTION.ease })(T);

  /* ---- handoff: the white app opens out of where the ball vanished ---- */
  const reveal = animate({ from: 0, to: 1720, start: CUES.Resolve, end: CUES.Resolve + 0.5, ease: MOTION.ease })(T);

  /* ---- wordmark ---- */
  const letters = String(tw.wordmark).split('');
  const dotIn = animate({ from: 0, to: 1, start: CUES.Resolve + 0.42, end: CUES.Resolve + 0.6, ease: MOTION.ease })(T);
  const subFade = animate({ from: 0, to: 1, start: CUES.Resolve + 0.45, end: CUES.Resolve + 0.68, ease: MOTION.ease })(T);
  const abs = { position: 'absolute' };

  return (
    <div
      data-screen-label={'Cueing ' + T.toFixed(1) + 's'}
      style={{ position: 'relative', width: W, height: H, overflow: 'hidden', background: '#04100A', fontFamily: 'Archivo, sans-serif' }}
    >
      {/* felt, lit from above the ball */}
      <div style={{ ...abs, inset: 0, opacity: feltIn,
        background: 'radial-gradient(58% 42% at 50% 47%, #1D7148 0%, #114A2F 46%, #072016 78%, #04100A 100%)' }} />
      {/* the spot the ball is sitting on */}
      <div style={{ ...abs, left: BALL_X - 19, top: BALL_Y + 25, width: 38, height: 10, borderRadius: 32,
        background: 'rgba(3,14,9,0.55)', opacity: feltIn * ballIn * (1 - clamp(-travelY / 60, 0, 1)) }} />

      {/* ball */}
      <div style={{
        ...abs, left: BALL_X - BALL_R, top: BALL_Y - BALL_R, width: BALL_R * 2, height: BALL_R * 2,
        borderRadius: BALL_R * 2, opacity: ballIn,
        background: 'radial-gradient(circle at 38% 32%, #FFFFFF 0%, #F1ECDD 42%, #B9B09A 78%, #6E6858 100%)',
        transform: 'translateY(' + travelY + 'px) scale(' + sx + ',' + sy + ')',
      }} />

      <Cue y={cueY} opacity={cueFade} />

      {/* the app opens out of the ball's vanishing point */}
      <div style={{
        ...abs, left: BALL_X - reveal / 2, top: 96 - reveal / 2, width: reveal, height: reveal,
        borderRadius: reveal, background: '#FFFFFF',
      }} />

      {/* wordmark, on the white */}
      <div style={{ ...abs, left: GUTTER, top: MARK_BOTTOM - MASK_H, display: 'flex', alignItems: 'flex-end' }}>
        {letters.map((ch, i) => {
          const st = CUES.Resolve + 0.24 + i * 0.04;
          const y = animate({ from: MASK_H, to: 0, start: st, end: st + 0.36, ease: MOTION.ease })(T);
          return (
            <div key={i} style={{ height: MASK_H, overflow: 'hidden' }}>
              <div style={{ transform: 'translateY(' + y + 'px)', fontSize: MARK_SIZE, lineHeight: MASK_H + 'px',
                fontWeight: 800, letterSpacing: '-0.03em', color: '#15181B', whiteSpace: 'pre' }}>{ch}</div>
            </div>
          );
        })}
        <div style={{ position: 'relative', width: DOT + 9, height: MASK_H }}>
          <div style={{ ...abs, left: 9, top: BASE_IN_MASK - DOT, width: DOT, height: DOT, borderRadius: DOT,
            background: accent, opacity: dotIn, transform: 'scale(' + (0.4 + 0.6 * dotIn) + ')' }} />
        </div>
      </div>
      <div style={{ ...abs, left: GUTTER, top: RULE_Y, width: W - GUTTER * 2, height: 2, background: '#D9DEE3',
        opacity: subFade, transformOrigin: 'left center', transform: 'scaleX(' + subFade + ')' }} />
      <div style={{ ...abs, left: GUTTER, top: RULE_Y + 16, opacity: subFade,
        fontSize: 12, fontWeight: 800, letterSpacing: '0.18em', textTransform: 'uppercase', color: accent }}>{tw.tagline}</div>
    </div>
  );
}

function KakulCueing() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
      <CompositionStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#04100A">
        <Piece tw={tw} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Brand" />
        <TweakText label="Wordmark" value={tw.wordmark} onChange={(v) => setTweak('wordmark', v)} />
        <TweakText label="Tagline" value={tw.tagline} onChange={(v) => setTweak('tagline', v)} />
        <TweakColor label="Accent" value={tw.accent} options={['#1558D6', '#15181B', '#1E7A4C', '#D7301F']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}

window.KakulCueing = KakulCueing;
