/* global React, useComposition, CompositionStage, Easing, animate, clamp, useTweaks, TweaksPanel, TweakSection, TweakToggle, TweakColor, TweakText */

// Exactly three motion helpers — nothing eases outside these.
const MOTION = {
  rise: Easing.easeOutQuart,      // rules drawing, letters climbing, type settling
  drop: Easing.easeOutBack,       // the ball landing
  wipe: Easing.easeInOutCubic,    // the ground handing off to the app
};

const W = 390, H = 844;
const GUTTER = 40;
const BASELINE = 430;      // wordmark box bottom
const MARK_SIZE = 64;
const MASK_H = 74;         // letter mask, a little taller than the cap height
const BASE_IN_MASK = 58;   // measured text baseline inside that mask
const RULE_Y = 462;
const BALL = 13;

const DARK = { ground: '#0E1316', type: '#FFFFFF', rule: '#2B3439', accent: '#4C8DFF' };
const LIGHT = { ground: '#FFFFFF', type: '#15181B', rule: '#D9DEE3', accent: '#1558D6' };

// One frame of the composition, painted in either palette. Rendered twice —
// the light copy lives inside the wipe mask, so the type inverts exactly at
// the wipe line instead of cross-fading.
function Frame({ tw, T, CUES, c }) {
  const letters = String(tw.wordmark).split('');

  const ruleScale = animate({ from: 0, to: 1, start: 0.12, end: CUES.Build + 0.1, ease: MOTION.rise })(T);

  const ballDrop = animate({ from: -120, to: 0, start: CUES.Accent, end: CUES.Accent + 0.42, ease: MOTION.drop })(T);
  const ballFade = animate({ from: 0, to: 1, start: CUES.Accent, end: CUES.Accent + 0.14, ease: MOTION.rise })(T);

  const subFade = animate({ from: 0, to: 1, start: CUES.Accent + 0.28, end: CUES.Resolve + 0.1, ease: MOTION.rise })(T);
  const subRise = animate({ from: 10, to: 0, start: CUES.Accent + 0.28, end: CUES.Resolve + 0.15, ease: MOTION.rise })(T);

  return (
    <div style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, background: c.ground, overflow: 'hidden' }}>
      {/* wordmark — each letter climbs out from behind the rule line */}
      <div style={{
        position: 'absolute', left: GUTTER, top: BASELINE - MASK_H,
        display: 'flex', alignItems: 'flex-end', gap: 0,
      }}>
        {letters.map((ch, i) => {
          const start = CUES.Build + i * 0.09;
          const y = animate({ from: MASK_H, to: 0, start: start, end: start + 0.52, ease: MOTION.rise })(T);
          return (
            <div key={i} style={{ height: MASK_H, overflow: 'hidden' }}>
              <div style={{
                transform: 'translateY(' + y + 'px)',
                fontSize: MARK_SIZE, lineHeight: MASK_H + 'px', fontWeight: 800,
                letterSpacing: '-0.03em', color: c.type, whiteSpace: 'pre',
              }}>{ch}</div>
            </div>
          );
        })}

        {/* the full stop is a ball, sitting on the type baseline — the only snooker cue in the piece */}
        <div style={{ position: 'relative', width: BALL + 9, height: MASK_H }}>
          <div style={{
            position: 'absolute', left: 9, top: BASE_IN_MASK - BALL,
            width: BALL, height: BALL, borderRadius: BALL, background: c.accent,
            opacity: ballFade, transform: 'translateY(' + ballDrop + 'px)',
          }} />
        </div>
      </div>

      {/* the rule the letters climbed out of */}
      <div style={{
        position: 'absolute', left: GUTTER, top: RULE_Y, width: W - GUTTER * 2, height: 2,
        background: c.rule, transformOrigin: 'left center', transform: 'scaleX(' + ruleScale + ')',
      }} />

      <div style={{
        position: 'absolute', left: GUTTER, top: RULE_Y + 16,
        opacity: subFade, transform: 'translateY(' + subRise + 'px)',
        fontSize: 12, fontWeight: 800, letterSpacing: '0.18em', textTransform: 'uppercase', color: c.accent,
      }}>{tw.tagline}</div>
    </div>
  );
}

function Piece({ tw }) {
  const { T, CUES } = useComposition();
  const light = { ...LIGHT, accent: tw.accent };

  // The white ground wipes down over the dark one; the type inverts at the line.
  const maskH = animate({ from: 0, to: H, start: CUES.Resolve, end: CUES.Resolve + 0.5, ease: MOTION.wipe })(T);

  return (
    <div
      data-screen-label={'Launch ' + T.toFixed(1) + 's'}
      style={{ position: 'relative', width: W, height: H, overflow: 'hidden', fontFamily: 'Archivo, sans-serif' }}
    >
      <Frame tw={tw} T={T} CUES={CUES} c={DARK} />
      <div style={{ position: 'absolute', left: 0, top: 0, width: W, height: clamp(maskH, 0, H), overflow: 'hidden' }}>
        <Frame tw={tw} T={T} CUES={CUES} c={light} />
      </div>
      {/* a rule leads the wipe, so the handoff reads as a deliberate pass */}
      <div style={{
        position: 'absolute', left: 0, top: clamp(maskH, 0, H) - 2, width: W, height: 2,
        background: light.accent, opacity: maskH > 1 && maskH < H ? 1 : 0,
      }} />
    </div>
  );
}

function KakulLaunch() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
      <CompositionStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0E1316">
        <Piece tw={tw} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Brand" />
        <TweakText label="Wordmark" value={tw.wordmark} onChange={(v) => setTweak('wordmark', v)} />
        <TweakText label="Tagline" value={tw.tagline} onChange={(v) => setTweak('tagline', v)} />
        <TweakColor label="Accent" value={tw.accent} options={['#1558D6', '#15181B', '#1E7A4C', '#D7301F']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}

window.KakulLaunch = KakulLaunch;
