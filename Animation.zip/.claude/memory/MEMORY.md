# Memory Index

- [Kakul Club Project Context](project_context.md) — Business overview, tech stack, current stage, key files
- [Tables & Rates](tables_rates.md) — Table inventory, hourly rates, club hours, staff PIN (PLACEHOLDERS — unconfirmed)
- [App Behaviour Rules](app_behaviour.md) — Billing formula, booking slots, loyalty points, tournament bracket logic
- [Design System](design_system.md) — "Felt & Brass" visual direction, palette, fonts, icon set → full spec in `.claude/specs/phase-1-design-tokens.md`
- [Launch Animation](../specs/phase-3-launch-animation.md) — "Down the cue" splash: 1100ms, cold start only, needs react-native-svg
- [Design Decisions](design_decisions.md) — Why Expo, why no nav lib, why AsyncStorage, why PIN-gated single app
- [User Profile](user_profile.md) — Owner, working style, review preferences
- [Always Update Memory](feedback_update_memory.md) — Update memory files after every code change, no need to ask
