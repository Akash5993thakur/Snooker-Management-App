# Phase 3 — Launch Animation ("Down the cue")

**Chosen option:** the cueing animation. A type-led alternative was built and rejected; it is not specified here.
**Plays:** cold start only, 1100 ms. Not on resume from background.
**Artboard:** 390 × 844 pt. All measurements in points, all times in milliseconds from launch.
**Preview:** `design/canvas/Kakul Launch Animation - Cueing.dc.html` (scrub or press Replay).

---

## 1. What happens

The player's own view, looking down the shaft at the cue ball on lit felt. The cue **feathers twice** — the small back-and-forth a player makes before committing — then draws back and snaps. The ball squashes on contact, fires away up the table shrinking with distance, and the white app opens out of the point where it vanished, with the wordmark building on it.

The feathering is the point. Without it, it is a stick poking a circle; with it, it reads as cueing.

---

## 2. Timing

| Beat | Window (ms) | What |
| --- | --- | --- |
| Felt lights up | 15 → 229 | Radial pool of light blooms around the ball |
| Ball settles in | 55 → 189 | Opacity, with its contact shadow |
| Cue slides into frame | 61 → 244 | y +190 → 0 from below the bottom edge |
| Feather stroke 1 | 244 → 382 | 13 pt sine, no contact — anticipation |
| Feather stroke 2 | 382 → 519 | Identical; two is what a player does |
| Draw back | 519 → 605 | y 0 → +40, `easeOutQuart` — slow, deliberate |
| Strike | 605 → 672 | y +40 → −14, `easeInQuart`, accelerating into contact |
| Contact squash | 672 → 712 | Ball 1.22 × 0.82, recovering |
| Ball fires away | 672 → 856 | y −520, scale 1 → 0.3, `easeOutSine` |
| Cue follows through | 727 → 856 | Recedes to +150 and fades |
| White opens | 856 → 1008 | Circle from the vanishing point, ø 0 → 1720 pt |
| Wordmark builds | 929 → 1088 | Five letters, 12 ms stagger, 110 ms each |
| Hand off to Home | 1100 | Splash unmounts, no cross-fade |

**Easing — exactly three curves, nothing outside them:**

| Name | Curve | Used for |
| --- | --- | --- |
| `ease` | easeOutQuart | Arrivals, draw-back, cue recede, white reveal |
| `snap` | easeInQuart | The strike only |
| `glide` | easeOutSine | Ball travel and recession |

`glide` matters: `easeOutQuart` on the ball throws it off-screen in the first third of its window and reads as a teleport.

The white reveal must be **ø 1720 pt**. It is centred at (195, 96) and has to clear the far corner: `hypot(195, 748) = 773 pt` radius.

---

## 3. Geometry

| Element | Spec |
| --- | --- |
| Artboard | 390 × 844 pt, base `#04100A` |
| Felt | radial 58% 42% at 50% 47% — `#1D7148` 0% · `#114A2F` 46% · `#072016` 78% · `#04100A` 100% |
| Ball | ø 52 pt at (195, 430) — radial `#FFFFFF` 0% · `#F1ECDD` 42% · `#B9B09A` 78% · `#6E6858` 100%, centre 38% 32% |
| Contact shadow | 38 × 10 pt ellipse, 25 pt below centre, 55% black |
| Cue | tip ø 6.4 pt → butt 22 pt, tip rests 16 pt short of the ball, 1.5° tilt |
| Cue shaft | `#C08F4E` 0% → `#D9AE72` 38% → `#8A6134` 100%, tapered |
| Cue butt | `#241610` → `#150C08`, lower 190 pt |
| Ferrule / tip | `#EFEADC` 22 pt band, `#2E6FD0` chalk 10 pt |
| Wordmark | Archivo 800, 64 pt / 74, −3% tracking, `C.ink`, flush left at gutter 40, box bottom y 430 |
| Letter clip | 74 pt tall, overflow hidden; text baseline 58 pt from its top |
| Full stop | ø 13 pt circle in `C.brass`, on the baseline, 9 pt after the last letter |
| Rule | x 40 → 350, 2 pt, `C.rule`, y 462 |
| Tagline | Archivo 800, 12 pt, +18% tracking, caps, `C.brass`, y 478 |

The final frame uses the app's own tokens (`C.ground`, `C.ink`, `C.rule`, `C.brass`) from `phase-1-design-tokens.md` §1, so the splash resolves into the Home screen with no colour shift.

---

## 4. Implementation notes

- **New dependency: `react-native-svg`.** Two radial gradients (the light pool on the felt, the highlight on the ball) and the tapered cue shape need it — `expo-linear-gradient` cannot do radial. Alternative: bake the felt and ball as two static PNGs and skip the dependency.
- **Native driver:** everything animated is `translate`, `scale` or `opacity`, so `useNativeDriver: true` throughout. No blur, no shadow layers, no per-frame layout.
- Drive the whole piece from **one** `Animated.Value` 0 → 1 over 1100 ms and `interpolate` every property off it. Do not run twelve timings.
- The feather is a sine on the cue's y, not two tweens: `y = -13 * sin(phase * 2π)` over two 138 ms cycles.
- **Reduced motion:** if `AccessibilityInfo.isReduceMotionEnabled()`, render the final white frame and hold 300 ms.
- **If loading overruns:** hold the final frame. Never cut to a spinner.
- The wordmark is a type stand-in. If a logo arrives and is wider than ~270 pt, it replaces the letter build and sits above the rule as its own lockup.

---

## 5. Cuts available if 1100 ms is too long

| Change | Saves | Cost |
| --- | --- | --- |
| One feather instead of two | 137 ms | The main thing that makes it read as cueing |
| Drop the wordmark letter stagger | 48 ms | Wordmark appears as a block |
| Shorten the white reveal to 100 ms | 52 ms | Handoff feels abrupt |
